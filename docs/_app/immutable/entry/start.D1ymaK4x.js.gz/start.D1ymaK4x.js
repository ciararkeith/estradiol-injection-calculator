import{l as o,a as r}from"../chunks/8R8m7_f4.js";export{o as load_css,r as start};
